values  = [100,200,300,400]
slice = values[1:3]
print(slice)
