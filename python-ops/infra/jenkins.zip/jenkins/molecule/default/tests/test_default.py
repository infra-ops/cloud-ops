import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_commands(host):
    assert host.exists('java')
    assert host.exists('git')
    assert host.exists('gradle')


def test_jenkins_package(Package):
    jenkinsservice = Package('jenkins.noarch')
    assert jenkinsservice.is_installed
    assert jenkinsservice.version.startswith("2.54")


def test_jenkins_running_and_enabled(Service):
    jenkinsservice = Service("jenkins.service")
    assert jenkinsservice.is_running
    assert jenkinsservice.is_enabled