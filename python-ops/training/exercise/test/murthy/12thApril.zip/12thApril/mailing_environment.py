EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'chakrabortyrock@gmail.com'
EMAIL_HOST_PASSWORD = 'XXXXXXXXX'
EMAIL_PORT = 587
